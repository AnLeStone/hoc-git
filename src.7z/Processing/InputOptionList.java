package Processing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class InputOptionList {

	String [] optionList;
	int length;

	public InputOptionList() {
		super();
		
		optionList = null;
		length = 0;
	}
	
	public InputOptionList(String [] optionList) {
		super();
		
		this.optionList = optionList;
		length = optionList.length;
	}
	/**
	 * Read file Option list from path
	 * @param path
	 */
	public void readOptionList (String path) {
		
		File file = new File(path);
		
		System.out.println("Option List path: "+path);
		
		if (!file.exists()) {
			System.out.println("Input Option List is not exist!");
			return;
		}
		
		optionList = new String [1000];
		
		BufferedReader reader;
		
		try
		{                      
			reader = new BufferedReader(new FileReader(file));
		    String line = null;
		    
		    while ((line = reader.readLine()) != null)
		    {
		    	int i = 1;
		        if (line.startsWith("-"))
		        {
		           optionList[i] = line;
		           System.out.println("read option: "+ line);
		           i++;
		        }
		    }
		    
		    reader.close();	
		}
		catch (IOException ex)
		{
		    ex.printStackTrace();
		}               

		   

	}
	
}
