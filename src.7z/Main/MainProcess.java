package Main;

import Processing.InputOptionList;

public class MainProcess {
	
	static String path = "src/input/OptionList.txt";
	
	public static void main (String [] args) {
		
		InputOptionList input = new InputOptionList();
		
		input.readOptionList(path);
		
	}
	
}
