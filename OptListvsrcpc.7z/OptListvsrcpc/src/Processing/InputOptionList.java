package Processing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InputOptionList {

	List<String> optionList;
	int length;

	public InputOptionList() {
		super();
		
		optionList = null;
		length = 0;
	}
	
	public InputOptionList(List<String> optionList) {
		super();
		
		this.optionList = optionList;
		length = optionList.size();
	}
	/**
	 * Read file Option list from path
	 * @param path
	 */
	public void readOptionList (String path) {
		
		File file = new File(path);
		
		System.out.println("Option List path: "+path);
		
		if (!file.exists()) {
			System.out.println("Input Option List is not exist!");
			return;
		}
		
		optionList = new ArrayList<>();
		
		BufferedReader reader;
		
		try
		{                      
			reader = new BufferedReader(new FileReader(file));
		    String line = null;
		    int i = 0, amount = 0;
		    while ((line = reader.readLine()) != null)
		    {	
		    	i++;
		        if (line.startsWith("-"))
		        {		        	
		           optionList.add(line);		           
		           //System.out.println("read line "+i+": "+ line );
		           amount++;
		        }
		    }
		   length = amount;
		    reader.close();	
		}
		catch (IOException ex)
		{
		    ex.printStackTrace();
		}              		

	}
	
	public List<String> getOptionList() {
		if (optionList == null || optionList.size() == 0) {
			System.out.println("Empty results");
			return null;
		}
		return optionList;
	}
	
}
