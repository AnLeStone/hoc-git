package Processing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputRcpc {
	
	int LIMIT_LINE = 10000;
	String GENERAL_INFO_REGEX = ""
			+ "("
			+ "(<BuildOptions)|"
			+ "(<BuildMode)|"
			+ "(<IndividualOptions)|"
			+ "(<CompileOptions)|"
			+ "(<AssembleOptions)|"
			+ "(<LinkOptions)|"
			+ "(<Option)|"
			+ "(<IOHeaderGenerationOptions)|"
			+ "(<LibraryGenerateOptions)|"
			+ "(<GeneralOptions)"
			+ "(</IndividualOptions)|"
			+ "(</CompileOptions)|"
			+ "(</AssembleOptions)|"
			+ "(</LinkOptions)|"
			+ "(</IOHeaderGenerationOptions)|"
			+ "(</LibraryGenerateOptions)|"
			+ "(</GeneralOptions)"
			+ ")"
			+ "(.*)(>$)";
	List<String> rcpc;
	
	public InputRcpc() {
		
		rcpc = null;
	}
	
	public InputRcpc(List<String> rcpc) {
		super();
		
		this.rcpc = rcpc;
	}
	/**
	 * Read file Option list from path
	 * @param path
	 */
	public void readRcpc (String path) {
		
		File file = new File(path);
		
		System.out.println("Rcpc path: "+path);
		
		if (!file.exists()) {
			System.out.println("Rcpc file is not exist!");
			return;
		}
		
		rcpc = new ArrayList<>();
		
		BufferedReader reader;
		
		try
		{                      
			reader = new BufferedReader(new FileReader(file));
		    String line = null;
		    int i = 0, amount = 0;
		    while ((line = reader.readLine()) != null)
		    {	
		    	i++;
		    	if (amount == LIMIT_LINE)
	            {
	        	   break;
	            }
		    	
		        if (validateTextLine(line))
		        {
		          
		           String result = extractDataFromLine(line);
		           rcpc.add("line "+i+":"+result);	
		           //System.out.println("read line "+(i+1)+": "+ result );
		           amount++;
		           
		           
		        }
		    }
		    System.out.println("Total legal line: "+amount);
		    reader.close();	
		}
		catch (IOException ex)
		{
		    ex.printStackTrace();
		}              		

	}
	
	public List<String> getRcpc() {
		return rcpc;
	}
	
	public String extractDataFromLine(String line) {
		String extractedData = new String ();

		Pattern patternObj = Pattern.compile(GENERAL_INFO_REGEX);
		Matcher matchObj = patternObj.matcher(line);
		if (matchObj.find()) {
			return matchObj.group(0);
		}

		return null;
	}
	
	private boolean validateTextLine(String line) {
		boolean isValid = true;
		Pattern patternObj = Pattern.compile(GENERAL_INFO_REGEX);
		Matcher matchObj = patternObj.matcher(line);
		if (!matchObj.find()) {
			isValid = false;
		}

		return isValid;
	}
}
