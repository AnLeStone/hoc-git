package Processing;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CompareListvsRcpc {
	
	List<String>  optlist;
	List<String>  rcpc;
	String regex_getoption_rcpc = "(<Option>)(.*)=(.*)(</Option>)$";
	String GENERAL_INFO_REGEX = ""
			+ "("
//			+ "(<BuildOptions)|"
			+ "(<BuildMode)|"
			+ "(<IndividualOptions)|"
			+ "(<CompileOptions)|"
			+ "(<AssembleOptions)|"
			+ "(<LinkOptions)|"
			+ "(<IOHeaderGenerationOptions)|"
			+ "(<LibraryGenerateOptions)|"
			+ "(<GeneralOptions)"
			+ "(</IndividualOptions)|"
			+ "(</CompileOptions)|"
			+ "(</AssembleOptions)|"
			+ "(</LinkOptions)|"
			+ "(</IOHeaderGenerationOptions)|"
			+ "(</LibraryGenerateOptions)|"
			+ "(</GeneralOptions)"
			+ ")"
			+ "(.*)(>$)";

	String phase_regex = "((<)|(</))([a-zA-Z]+)";
	
	public CompareListvsRcpc (InputOptionList optlist, InputRcpc rcpc) {
		this.optlist = optlist.getOptionList();
		this.rcpc = rcpc.getRcpc();
	}
	
	public void runCompare() {
		
		PrintWriter writer;
		PrintWriter writer01;
		List <String> nocmdline = new ArrayList<>();
		boolean isOption = false;
		
		try {
			writer = new PrintWriter("src/output/option_details.txt", "UTF-8");
			writer01 = new PrintWriter("src/output/Thống kê option.txt", "UTF-8");
			
			for (String opt : optlist) {
				
				writer.println("\n//================================ " +opt+ " ===============================");
				System.out.println("Running for "+ opt +" ...");
				int countopt = 0;

				Stack<String> stack = new Stack<>();
				List<String> arrayPhase = new ArrayList<>();
				List<String> source = new ArrayList<>();
				int temp = 0;
				String tempsource = "";
				
				for (String line : rcpc) {
					
					String result = extractGeneralFromLine(line);
					
					if (result != null)
						writer.println(result);	
					
					String option = getOption(line);
					if (opt.equalsIgnoreCase(option)) {
						
						writer.println(line);
					    countopt++;					
						isOption = true;
					}
					
					
					String opentab = getPhase(line);
					if (opentab != null)
						if (stack.empty() || !stack.lastElement().equals(opentab))
						{
							//nay chi xu ly khi co tab indi mo ra
							if (opentab != null && !opentab.equals("Option")) {
								stack.push(new String(opentab));
								if (opentab.equals("IndividualOptions")) {
									arrayPhase.add("<i ");
									tempsource = "> "+line;
								}
								System.out.println("Open: "+opentab);
							}
						}
						else	
						{	// khi dong tab -> neu co option > get tab name					
							if (stack.lastElement().equals(opentab))
							{
								String closetab = opentab;									
								System.out.println("Close: "+closetab);
								if (isOption) {
									if (closetab.equals("IndividualOptions")) {									
										arrayPhase.add(" i/>");
										source.add(tempsource);
										System.out.println("indi file: "+tempsource);
									}
									else {
										arrayPhase.add(closetab.substring(0, 4));
									}
									isOption = false;
								}
								if (closetab.equals("IndividualOptions"))
								{
									arrayPhase.remove(arrayPhase.size()-1);
								}
								stack.pop();							
							}							
						}
						
				}
				
				
				if (countopt == 0) {
					nocmdline.add(opt);
				}
				else
				{
					writer01.println("\n-------------------------------------------"+countopt+" point: "+opt);
					for (String line : arrayPhase) {
						if (line.equals("<i "))
							writer01.print("\n"+line);
						else if (line.equals(" i/>"))
							writer01.print(line+"\n");
						else
							writer01.print(line + "/");
					}
					writer01.println();
					for(String line : source) {
						writer01.println(line);
					}
				}
			}
			
			writer01.println("//~~~~~~ No command line list ~~~~~~~~");
			for (String line : nocmdline) {
				writer01.println(line);
			}
			writer.close();
			writer01.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		
	}
	
	
	/**
	 *  get command line
	 * @param line
	 * @return command line
	 */
	public String getPhase(String line) {
		
		if (!validatePhaseLine(line)) return null;
		
		String extractedData = new String ();

		Pattern patternObj = Pattern.compile(phase_regex);
		Matcher matchObj = patternObj.matcher(line);
		if (matchObj.find()) {
//			System.out.println(line);
//			System.out.println("Group 0: " +matchObj.group(0));
//			System.out.println("Group 1: " +matchObj.group(1));
//			System.out.println("Group 2: " +matchObj.group(2));
//			System.out.println("Group 3: " +matchObj.group(3));
//			System.out.println("Group 4: " +matchObj.group(4));
//			System.out.println("Group 5: " +matchObj.group(5));
			switch (matchObj.group(4)) {
				case "BuildOptions":
				case "BuildMode":
					return null;
				default: break;
			}
			return matchObj.group(4);
		}

		return null;
	}
	
	/**
	 *  get command line
	 * @param line
	 * @return command line
	 */
	public String getOption(String line) {
		
		if (!validateOptionLine(line)) return null;
		
		String extractedData = new String ();

		Pattern patternObj = Pattern.compile(regex_getoption_rcpc);
		Matcher matchObj = patternObj.matcher(line);
		if (matchObj.find()) {
			return matchObj.group(2);
		}

		return null;
	}
	
	/**
	 *  get line general information
	 * @param line
	 * @return general information line
	 */
	public String extractGeneralFromLine(String line) {
		
		if (!validateGeneralLine(line)) return null;
		
		String extractedData = new String ();

		Pattern patternObj = Pattern.compile(GENERAL_INFO_REGEX);
		Matcher matchObj = patternObj.matcher(line);
		if (matchObj.find()) {
			return matchObj.group(0);
		}

		return null;
	}
	
	private boolean validateOptionLine(String line) {
		boolean isValid = true;
		Pattern patternObj = Pattern.compile(regex_getoption_rcpc);
		Matcher matchObj = patternObj.matcher(line);
		if (!matchObj.find()) {
			isValid = false;
		}
		
		return isValid;
	}
	
	private boolean validateGeneralLine(String line) {
		boolean isValid = true;
		Pattern patternObj = Pattern.compile(GENERAL_INFO_REGEX);
		Matcher matchObj = patternObj.matcher(line);
		if (!matchObj.find()) {
			isValid = false;
		}

		return isValid;
	}
	
	private boolean validatePhaseLine(String line) {
		boolean isValid = true;
		Pattern patternObj = Pattern.compile(phase_regex);
		Matcher matchObj = patternObj.matcher(line);
		if (!matchObj.find()) {
			isValid = false;
		}

		return isValid;
	}
}