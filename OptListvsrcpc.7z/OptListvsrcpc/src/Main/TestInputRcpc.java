package Main;

import java.util.List;

import Processing.InputRcpc;

public class TestInputRcpc{
	

	static String path = "src/input/RX01.rcpc";
	
	public static void main (String [] args) {
		
		InputRcpc input = new InputRcpc();
		
		input.readRcpc(path);
		
		List<String> list = input.getRcpc();
		
		for (String line : list){
			System.out.println(line);
		}
		
	}

}
