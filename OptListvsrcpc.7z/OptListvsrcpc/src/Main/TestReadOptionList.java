package Main;

import java.util.List;

import Processing.InputOptionList;

public class TestReadOptionList {
	
	static String path = "src/input/OptionList.txt";
	
	public static void main (String [] args) {
		
		InputOptionList input = new InputOptionList();
		
		input.readOptionList(path);
		
		List<String> list = input.getOptionList();
		
		for (String line : list){
			System.out.println(line);
		}

		
	}
	
}
