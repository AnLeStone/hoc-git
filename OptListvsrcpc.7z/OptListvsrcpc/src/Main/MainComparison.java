package Main;

import java.util.List;

import Processing.CompareListvsRcpc;
import Processing.InputOptionList;
import Processing.InputRcpc;

public class MainComparison {

	public static void main (String [] args) {
		
		String pathrcpc = "src/input/RX01.rcpc";
		String pathoptionlist = "src/input/OptionList.txt";
		
		InputRcpc rcpc = new InputRcpc();
		rcpc.readRcpc(pathrcpc);
		
		InputOptionList optlist = new InputOptionList();
		optlist.readOptionList(pathoptionlist);
		
		CompareListvsRcpc compare = new CompareListvsRcpc(optlist, rcpc);
		compare.runCompare();
		
	}

}
